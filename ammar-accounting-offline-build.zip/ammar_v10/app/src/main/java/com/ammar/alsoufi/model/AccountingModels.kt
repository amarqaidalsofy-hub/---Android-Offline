package com.ammar.alsoufi.model

enum class AgentType { COMMISSION, BUYER, BOTH }

data class Agent(
    val id: Long = 0,
    val name: String,
    val phone: String = "",
    val type: AgentType = AgentType.BOTH,
    val commissionPercent: Double = 0.0,
    val balance: Long = 0
)

data class Product(
    val id: Long = 0,
    val name: String,
    val barcode: String = "",
    val quantity: Double = 0.0,
    val purchasePrice: Long = 0,
    val salePrice: Long = 0
)

data class InvoiceLine(
    val productId: Long,
    val quantity: Double,
    val unitPrice: Long,
    val discount: Long = 0
) {
    val total: Long get() = (quantity * unitPrice).toLong() - discount
}

enum class InvoiceType { SALE, PURCHASE, SALE_RETURN, PURCHASE_RETURN }

data class Invoice(
    val id: Long = 0,
    val number: String,
    val type: InvoiceType,
    val partyId: Long? = null,
    val agentId: Long? = null,
    val total: Long,
    val paid: Long = 0,
    val createdAt: Long = System.currentTimeMillis()
) {
    val remaining: Long get() = total - paid
}

enum class CashMovementType { RECEIPT, PAYMENT }

data class CashMovement(
    val id: Long = 0,
    val type: CashMovementType,
    val amount: Long,
    val partyName: String = "",
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
