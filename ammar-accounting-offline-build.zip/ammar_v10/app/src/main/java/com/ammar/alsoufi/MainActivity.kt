package com.ammar.alsoufi

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import com.ammar.alsoufi.data.AccountingDbHelper

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AmmarApp(AccountingDbHelper(this)) }
    }
}

@Composable
fun AmmarApp(db: AccountingDbHelper) {
    var screen by remember { mutableStateOf("الرئيسية") }
    var refresh by remember { mutableStateOf(0) }
    val pages = listOf("الرئيسية","الوكلاء","الأصناف","الفواتير","الصندوق","التقارير")
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
      MaterialTheme {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text("عمار الصوفي", style=MaterialTheme.typography.headlineMedium)
            Text("نظام محاسبي خاص • الريال اليمني")
            Spacer(Modifier.height(12.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement=Arrangement.spacedBy(5.dp)) {
                pages.forEach { p -> Button(onClick={screen=p}) { Text(p) } }
            }
            Spacer(Modifier.height(18.dp))
            when(screen) {
                "الرئيسية" -> Dashboard(db, refresh)
                "الوكلاء" -> AgentForm(db){refresh++}
                "الأصناف" -> ProductForm(db){refresh++}
                "الفواتير" -> InvoiceForm(db){refresh++}
                "الصندوق" -> CashForm(db){refresh++}
                "التقارير" -> Reports(db, refresh)
            }
        }
      }
    }
}

@Composable fun Dashboard(db:AccountingDbHelper, refresh:Int) {
    Text("لوحة التحكم", style=MaterialTheme.typography.titleLarge)
    Spacer(Modifier.height(8.dp))
    Text("عدد الوكلاء: ${db.count("agents")}")
    Text("عدد الأصناف: ${db.count("products")}")
    Text("عدد الفواتير: ${db.count("invoices")}")
    Text("إجمالي الفواتير: ${db.sum("invoices","total")} ريال")
}

@Composable fun AgentForm(db:AccountingDbHelper,onSaved:()->Unit) {
    var name by remember{mutableStateOf("")}; var phone by remember{mutableStateOf("")}
    var commission by remember{mutableStateOf("")}
    Text("إضافة وكيل",style=MaterialTheme.typography.titleLarge)
    OutlinedTextField(name,{name=it},label={Text("اسم الوكيل")})
    OutlinedTextField(phone,{phone=it},label={Text("الهاتف")})
    OutlinedTextField(commission,{commission=it},label={Text("نسبة العمولة %")})
    Button(onClick={if(name.isNotBlank()){db.addAgent(name,phone,"BOTH",commission.toDoubleOrNull()?:0.0);name="";phone="";commission="";onSaved()}}){Text("حفظ الوكيل")}
}

@Composable fun ProductForm(db:AccountingDbHelper,onSaved:()->Unit) {
    var name by remember{mutableStateOf("")}; var barcode by remember{mutableStateOf("")}
    var qty by remember{mutableStateOf("")}; var purchase by remember{mutableStateOf("")}; var sale by remember{mutableStateOf("")}
    Text("إضافة صنف",style=MaterialTheme.typography.titleLarge)
    OutlinedTextField(name,{name=it},label={Text("اسم الصنف")})
    OutlinedTextField(barcode,{barcode=it},label={Text("الباركود")})
    OutlinedTextField(qty,{qty=it},label={Text("الكمية")})
    OutlinedTextField(purchase,{purchase=it},label={Text("سعر الشراء")})
    OutlinedTextField(sale,{sale=it},label={Text("سعر البيع")})
    Button(onClick={if(name.isNotBlank()){db.addProduct(name,barcode,qty.toDoubleOrNull()?:0.0,purchase.toLongOrNull()?:0,sale.toLongOrNull()?:0);name="";onSaved()}}){Text("حفظ الصنف")}
}

@Composable fun InvoiceForm(db:AccountingDbHelper,onSaved:()->Unit) {
    var number by remember{mutableStateOf("")}; var total by remember{mutableStateOf("")}; var paid by remember{mutableStateOf("")}
    Text("فاتورة بيع",style=MaterialTheme.typography.titleLarge)
    OutlinedTextField(number,{number=it},label={Text("رقم الفاتورة")})
    OutlinedTextField(total,{total=it},label={Text("الإجمالي بالريال")})
    OutlinedTextField(paid,{paid=it},label={Text("المدفوع")})
    Button(onClick={if(number.isNotBlank()){db.addInvoice(number,"SALE",null,null,total.toLongOrNull()?:0,paid.toLongOrNull()?:0);number="";total="";paid="";onSaved()}}){Text("حفظ الفاتورة")}
}

@Composable fun CashForm(db:AccountingDbHelper,onSaved:()->Unit) {
    var amount by remember{mutableStateOf("")}; var party by remember{mutableStateOf("")}; var note by remember{mutableStateOf("")}
    Text("سند قبض",style=MaterialTheme.typography.titleLarge)
    OutlinedTextField(amount,{amount=it},label={Text("المبلغ")})
    OutlinedTextField(party,{party=it},label={Text("من")})
    OutlinedTextField(note,{note=it},label={Text("البيان")})
    Button(onClick={if((amount.toLongOrNull()?:0)>0){db.addCash("RECEIPT",amount.toLong(),party,note);amount="";onSaved()}}){Text("حفظ سند القبض")}
}

@Composable fun Reports(db:AccountingDbHelper,refresh:Int) {
    Text("التقارير",style=MaterialTheme.typography.titleLarge)
    Text("إجمالي المبيعات المسجلة: ${db.sum("invoices","total")} ريال")
    Text("إجمالي المقبوضات: ${db.sum("cash_movements","amount")} ريال")
    Text("عدد حركات الصندوق: ${db.count("cash_movements")}")
}
