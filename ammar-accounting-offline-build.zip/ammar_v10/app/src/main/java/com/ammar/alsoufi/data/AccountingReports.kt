package com.ammar.alsoufi.data

data class ProfitSummary(
    val netSales: Long,
    val netPurchases: Long,
    val grossDifference: Long
)

class AccountingReports(private val db: AccountingDbHelper) {
    fun profitSummary(): ProfitSummary {
        val sales = db.totalSales() - db.totalSaleReturns()
        val purchases = db.totalPurchases() - db.totalPurchaseReturns()
        return ProfitSummary(sales, purchases, sales - purchases)
    }
}
